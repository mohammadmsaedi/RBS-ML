
from csv import writer
def append_list_as_row(file_name, list_of_elem):
    # Open file in append mode
    with open(file_name, 'a+', newline='') as write_obj:
        # Create a writer object from csv module
        csv_writer = writer(write_obj)
        # Add contents of list as last row in the csv file
        csv_writer.writerow(list_of_elem)

row1 = []
for i in range(1, 91):
    row1.append('BS'+str(i))
for i in range(1, 19):
    row1.append('RBS' + str(i))
print(row1)

append_list_as_row('MR_NoTime&Xleader.csv', row1)