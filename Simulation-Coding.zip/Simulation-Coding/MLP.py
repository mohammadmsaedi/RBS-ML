# from sklearn.datasets import make_classification
# from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD
import numpy as np
import pandas as pd
# from numpy import argmax
# from pandas import read_csv
# from sklearn.preprocessing import LabelEncoder
from tensorflow.keras import Sequential
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
from matplotlib import pyplot as plt
import time

start_time = time.time()
split_size = 0.3
# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/TimeSeries/Adrian/ML_data_RCH.csv')
# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/TimeSeries/Adrian/ML_data_450BSs.csv')
# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/TimeSeries/Adrian/90BSs/ML_data_90BS.csv')

# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Scale35000_BS450/ML_data_RCH_450BSs.csv')
# RBS_data.columns=["label","RSS1","RSS2","RSS3","RSS4","RSS5","RSS6","RSS7","RSS8","RSS9","RSS10",
#    "RCHRSS1","RCHRSS2","RCHRSS3","RCHRSS4","RCHRSS5","RCHRSS6","RCHRSS7","RCHRSS8","RCHRSS9","RCHRSS10"]

# Variable Speed:
# New
# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale30LBS/ML_data_30LBS.csv')

# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale90LBS/ML_data_90LBS_WS3.csv')
# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale90LBS/ML_data_90LBS_WS15.csv')
# RBS_data = pd.read_csv(
# 'c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale30LBS/ML_data_30LBS_WS3.csv')
# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale90LBS/LBS_bound_DividedBy10/ML_data_90LBS_WS3.csv')
# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/short_road/1000/5000km-225000s/ML_data_1000LBS_WS3.csv')

# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale450LBS/ML_data_450LBS_WS10.csv')

# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale450LBS/ML_data_450LBS_WS7.csv')

# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale450LBS/ML_data_450LBS_WS15.csv')

RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale450LBS/ML_data_450LBS_WS3.csv')
# RBS_data = pd.read_csv('c:/users/Mohammad/Desktop/Dataset3/MATLAB/Variant/Scale30LBS/ML_data_30LBS_WS3.csv')

# RBS_data.columns=["label","RSS1","RSS2","RSS3","RSS4","RSS5","RSS6","RSS7","RSS8","RSS9","RSS10"]

RBS_data.columns = ["label", "RSS1", "RSS2", "RSS3"]

# RBS_data.columns=["label","RSS1","RSS2","RSS3","RSS4","RSS5","RSS6","RSS7"]
# RBS_data.columns=["label","RSS1","RSS2","RSS3","RSS4","RSS5","RSS6","RSS7",
#  "RSS8","RSS9","RSS10","RSS11","RSS12","RSS13","RSS14","RSS15"]
# RBS_data = RBS_data.dropna()

print(RBS_data)
accuracy_list = []
precision_list = []
recall_list = []
f_score_list = []
loss_list = []
inputs = RBS_data[["RSS1", "RSS2", "RSS3"]]
# inputs=RBS_data[["RSS1","RSS2","RSS3","RSS4","RSS5","RSS6","RSS7"            ]]

# inputs = RBS_data[["RSS1","RSS2","RSS3","RSS4","RSS5","RSS6","RSS7",#  "RSS8","RSS9","RSS10","RSS11","RSS12","RSS13","RSS14","RSS15"]]

# "Tower_power","Gain","TAC","MCC","Handover","Rogue-Handover"]]
# inputs=RBS_data[["Tower_power","Gain","TAC","MCC","BS1","BS2","BS3","RBS1","RBS2","RCH1","RCH2","RCH3","RCH4","Handover","Output"]]
output = RBS_data[["label"]]
second_time = time.time()
for _ in range(10):
    inputs_tr, inputs_ts, output_tr, output_ts = train_test_split(inputs, output, test_size=0.3, random_state=42)
    # print("The features dimensions:")
    # print(inputs.shape)

    n_features = inputs_tr.shape[1]
    # print(n_features)
    # ### Step..: Feature Scaling
    # ##### A method to normalize the range of independent variables of features of data
    # Data normalization, generally performed during the data preprocessing step

    sc = StandardScaler()
    inputs_tr = sc.fit_transform(inputs_tr)
    inputs_ts = sc.transform(inputs_ts)

    # inputs_tr = pd.DataFrame(inputs_tr, columns =["RSS1","RSS2","RSS3","RSS4","RSS5","RSS6","RSS7","RSS8","RSS9","RSS10"])
    # inputs_ts = pd.DataFrame(inputs_ts, columns =["RSS1","RSS2","RSS3","RSS4","RSS5","RSS6","RSS7","RSS8","RSS9","RSS10"])
    # ValueError: Failed to find data adapter that can handle input: <class 'numpy.ndarray'>, <class 'pandas.core.frame.DataFrame'>
    inputs_tr = pd.DataFrame(inputs_tr, columns=["RSS1", "RSS2", "RSS3"])
    inputs_ts = pd.DataFrame(inputs_ts, columns=["RSS1", "RSS2", "RSS3"])
    # It is a good practice to use ‘relu‘ activation with a ‘he_normal‘ weight initialization. This combination goes
    # a long way to overcome the problem of vanishing gradients when training deep neural network models. For more on
    # ReLU, see the tutorial:

    # encode strings to integer
    # y = LabelEncoder().fit_transform(y)
    # split into train and test datasets
    # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33)
    # print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)
    # determine the number of input features

    # define model
    model = Sequential()
    model.add(Dense(50, activation='relu', kernel_initializer='he_normal',
                    input_shape=(n_features,)))  # input dimension = len(inputs)
    model.add(Dense(70, activation='tanh', kernel_initializer='he_normal'))
    model.add(Dense(10, activation='sigmoid', kernel_initializer='he_normal'))

    # model.add(Dense(3, activation='softmax'))

    #                      !!!!!!!!!!!                   #
    # softmax replaced by Sigmoid to use the second compile model
    model.add(Dense(1, activation='sigmoid'))

    # compile the model
    # model.compile(optimizer='adam', loss='sparse_categorical_crossentropy',metrics=['accuracy'])

    # compile the model
    sgd = SGD(learning_rate=0.01, momentum=0.8)  # lr by default is 0.01
    model.compile(optimizer=sgd, loss='binary_crossentropy', metrics=['accuracy'])
    # fit the model

    model.fit(inputs_tr, output_tr, epochs=20, batch_size=32, verbose=0)

    # evaluate the model

    loss, accuracy = model.evaluate(inputs_ts, output_ts, verbose=0)

    # ################################################################################

    accuracy_list.append(accuracy)
    loss_list.append(loss)
    predict_RBS = model.predict(inputs_ts)
    predict_RBS = (predict_RBS > 0.5)
    CM = confusion_matrix(output_ts, predict_RBS)

    TN, FP, FN, TP = CM[0][0], CM[0][1], CM[1][0], CM[1][1]
    # print(TP,FP,FN,TN)

    precision = (TP / (TP + FP))  # # of found positive / # of found
    precision_list.append(precision)
    recall = (TP / (TP + FN))  # # of found positive / # of positives
    recall_list.append(recall)
    # Accuracy2 = ((TP + TN) / (TP + FP + TN + FN))

    f_score = 2 * ((precision * recall) / (precision + recall))
    f_score_list.append(f_score)

# print("The list of 10 accuracy:", accuracy_list)
print("The maximum accuracy: %.3f " % max(accuracy_list))
print("The minimum accuracy: %.3f" % min(accuracy_list))
print("The average accuracy: %.3f " % ((max(accuracy_list) + min(accuracy_list)) / 2))

# print("\n The list of 10 precision: %.3f " % precision_list)
print("\n The maximum precision: %.3f " % max(precision_list))
print("The minimum precision: %.3f " % min(precision_list))
print("The average precision: %.3f " % ((max(precision_list) + min(precision_list)) / 2))

# print("\nThe list of 10 recall: %.3f " % recall_list)
print("\nThe maximum recall: %.3f " % max(recall_list))
print("The minimum recall: %.3f " % min(recall_list))
print("The average recall: %.3f " % ((max(recall_list) + min(recall_list)) / 2))

# print("\nThe list of 10 f-score:", f_score_list)
print("\nThe maximum f-score: %.3f " % max(f_score_list))
print("The minimum f-score: %.3f " % min(f_score_list))
print("The average f-score: %.3f " % ((max(f_score_list) + min(f_score_list)) / 2))

TPR = TP / (TP + FN) * 100  # TPR = Recall   LBS detection probability: TPR
TNR = TN / (FP + TN) * 100  # TNR = Specicity  RBS detection probability

FPR = FP / (FP + TN) * 100
print("\n FPR (False Positive Rate) =", FPR)

FNR = FN / (FN + TP) * 100
print("\n FNR (False Negative Rate) =", FNR)

print("\n ---algorithm execution time %s seconds ---" % (time.time() - start_time))

# Step 8: Confusion Matrix


print("\n LBS detection probability: TPR (True Positive Rate) =", TPR)

print("\n RBS detection probability: TNR (True Negative Rate) =", TNR)

# plt.clf()
plt.imshow(CM, interpolation='nearest', cmap=plt.cm.Wistia)
classNames = ['Rogue', 'Legitimate']
plt.title('MLP  Confusion Matrix - Test Data')
plt.ylabel('True label')
plt.xlabel('Predicted label')
tick_marks = np.arange(len(classNames))
plt.xticks(tick_marks, classNames, rotation=45)
plt.yticks(tick_marks, classNames)

s = [['TN', 'FP'], ['FN', 'TP']]

for i in range(2):
    for j in range(2):
        plt.text(j, i, str(s[i][j]) + " = " + str(CM[i][j]))

plt.show()

predict_Train = model.predict(inputs_tr)
predict_Train = (predict_Train > 0.5)

CM = confusion_matrix(output_tr, predict_Train)
# plt.clf()
plt.imshow(CM, interpolation='nearest', cmap=plt.cm.Wistia)
classNames = ['Rogue', 'Legitimate']
plt.title('MLP  Confusion Matrix - Train Data')
plt.ylabel('True label')
plt.xlabel('Predicted label')
tick_marks = np.arange(len(classNames))
plt.xticks(tick_marks, classNames, rotation=45)
plt.yticks(tick_marks, classNames)

s = [['TN', 'FP'], ['FN', 'TP']]

for i in range(2):
    for j in range(2):
        plt.text(j, i, str(s[i][j]) + " = " + str(CM[i][j]))
plt.show()


#   ### Step 8: Confusion Matrix

print("The loss is : {} ".format(loss))


# the second way is to obtain the accuracy
# import keras
from matplotlib import pyplot as plt

# history = model.fit(train_x, train_y,validation_split = 0.1, epochs=50, batch_size=4)
history = model.fit(inputs_tr, output_tr, validation_split=0.3, epochs=20, batch_size=32, verbose=0)

plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.ylabel('Accuracy')
plt.xlabel('epoch')
plt.legend(['training data', 'Cross validation'], loc='lower right')
plt.show()

plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])

from sklearn.metrics import classification_report

print(classification_report(output_ts, predict_RBS))

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model Loss')
plt.ylabel('Loss')
plt.xlabel('epoch')
plt.legend(['Train', 'Cross-Validation'], loc='upper right')
plt.show()

print("---Total time %s seconds ---" % (time.time() - start_time))
