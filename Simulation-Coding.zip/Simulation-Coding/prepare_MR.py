file_in =  open("RSS_90LBS_Time_Xleader.csv", "r")
file_out = open("MR.csv", "w")

for line in file_in:
    if line[:4] == "Time":
        headings =  line.split(",")
        file_out.write(line)
    else:
        elements = line.split(",")
        file_out.write(elements[0] + "," + elements[1] + ",")

        elements_f = [float(element) for element in elements]
        elements_f[0] = float("-inf")
        elements_f[1] = float("-inf")
        top6 = sorted(range(len(elements_f)), key=lambda i: elements_f[i])[-6:]

        output_str = ""
        for i in range(2, len(elements)):
            if i in top6:
                output_str = output_str + str(elements[i]).strip() + ","
            else:
                output_str = output_str + ","
        file_out.write(output_str[:-1] + "\n")

file_out.close()
file_in.close()
