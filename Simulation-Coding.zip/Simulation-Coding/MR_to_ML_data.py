import time

start_time = time.time()
file_in =  open("MR_NoTime&Xleader.csv", "r") # input file contains BS/RBS data ONLY (no Time or X_leader columns)
BS_data = []
first_line = True

for line in file_in:
    if first_line:
        # first line of input contains BS labels
        headings =  line.strip().split(",")
        first_line = False

        for heading in headings:
            # create new object for each BS/RBS in the dataset
            # store the element's name and initialise list of first 10 RSS values
            BS_data.append( { "name" : heading, "first_ten" : [], "done" : False } )

    else:
        # remaining lines in the input file are data
        elements = line.strip().split(",")
        
        # for each element in the input row 
        for i in range(len(elements)):

            # if it is not a value (i.e. not in the MR) and this BS has not yet filled it's "first 10" list
            if len(elements[i].strip()) == 0 and BS_data[i]["done"] == False:
                # clear any values currently in the "first 10" list
                BS_data[i]["first_ten"] = []

            # if it is a value (i.e. in the MR) and this BS has not yet filled it's "first 10" list
            if len(elements[i].strip()) > 0 and BS_data[i]["done"] == False:
                # add this value to the :first 10" list
                BS_data[i]["first_ten"].append(float(elements[i]))
                # if the list now contains 10 elements, this BS is done
                if len(BS_data[i]["first_ten"]) == 7:
                    BS_data[i]["done"] = True

file_in.close()

# now generate tyhe output
file_out = open("ML_data_90LBS_WS7.csv", "w")

# for each BS/RBS in the original input
for BS in BS_data:
    # if it is legitimate, prepend a "1" to the output row
    if BS["name"][:2] == "BS":
        output_str = "1,"
    # if it is rogue, prepend a "0" to the output row    
    else:
        output_str = "0,"
    
    # now complete the output row by adding the first 10 values found
    for RSS_value in BS["first_ten"]:
        output_str = output_str + str(RSS_value) + ","
    
    # write the output row to the file, removing the final comma character
    file_out.write(output_str[:-1] + "\n")
    
file_out.close()


print("-- The execution time %s" % (time.time()-start_time))
